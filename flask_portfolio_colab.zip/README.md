# Flask Portfolio Website

## Overview
A simple, unique personal portfolio site built with Flask, HTML, and CSS.

## Features
- Home page with profile info
- Contact form with validation
- Responsive and minimal design

## Installation
1. Install Flask:
   ```bash
   pip install flask
   ```
2. Run the app:
   ```bash
   python app.py
   ```
3. Open in browser:
   ```
   http://127.0.0.1:5000/
   ```

## License
Free to use for learning and personal projects.
